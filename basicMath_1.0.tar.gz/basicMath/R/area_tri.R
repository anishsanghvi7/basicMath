area_tri <-
function(b,h) {0.5*b*h}
