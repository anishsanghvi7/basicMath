sqr_root <-
function(x) {sqrt(x)}
