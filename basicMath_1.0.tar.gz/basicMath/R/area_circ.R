area_circ <-
function(r) {pi*r^2}
