circumference <-
function(r) {2*pi*r}
