divide <-
function(x, y){
  if (y == 0) {
    NULL
  } else {
    x/y
  }
}
