area_parallelogram <-
function(b,h) {b*h}
