area_sq <-
function(x) {x^2}
