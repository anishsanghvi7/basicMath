hypotenuse <-
function(x, y) {sqrt(x^2 + y^2)}
